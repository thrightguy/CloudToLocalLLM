﻿CloudToLocalLLM v3.6.10 - Portable Edition
==========================================

This is a portable version of CloudToLocalLLM that can be run from any location
without installation.

Quick Start:
1. Extract this ZIP file to any folder
2. Run CloudToLocalLLM-Portable.bat to start the application
3. All data will be stored in the 'data' subfolder

Features:
- No installation required
- Self-contained with all dependencies
- Portable data storage
- System tray integration
- Local LLM connection management

Requirements:
- Windows 10 version 1903 or later
- Visual C++ Redistributable (usually pre-installed)

For more information, visit:
https://github.com/imrightguy/CloudToLocalLLM

Support:
https://cloudtolocalllm.online
